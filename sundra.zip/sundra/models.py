import MySQLdb

def get_connecttion():
    hostname = '127.0.0.1'
    user = 'root'
    password = 'root'
    dbname = 'oms'
    port = 33061

    dbconn = MySQLdb.connect(hostname, user, password, dbname, port) #autocommit=True)

    return dbconn, dbconn.cursor()


def main():
    get_connecttion()

if __name__ == '__main__':
    main()

