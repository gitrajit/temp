#-*- coding: utf-8 -*-
import sys

#sys.stdout = sys.stderr = open('/home/pgtakhel/Error_VMB/log/GlobalVMB'+ lognow + '.log','wt')