# -*- coding: utf-8 -*-
#__author__ =  'gitrajit-singh.takhelmayum@amadeus'
from __future__ import unicode_literals
from flask import *
import logging
import base64
from MySQLdb import *
from functools import wraps


from models import get_connecttion
import home
import os


from werkzeug.utils import secure_filename

import datetime

#UPLOAD_FOLDER = '/home/blrauto/OMS/upload'
UPLOAD_FOLDER = './upload_file'

admin = Blueprint('admin', __name__,template_folder='templates')

def login_required(test):
    @wraps(test)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return test(*args, **kwargs)
        else:
            flash('You need to login as Admin')
            return redirect(url_for('ics.index'))
    return wrap

@admin.route('/login')
def admin_login():
    return render_template('admin_login.html')

@admin.route('/Admin-queue')
@login_required
def admin_Q():
    try:
        see1 = session['username'].upper()
        # see1 = 'git'
        dcn, cur = get_connecttion()

        cur.execute("SELECT * FROM master_data where status = 'New';;"),
        commentsList = cur.fetchall()
        return render_template("Admin_queue1.html", data=commentsList, use=see1)
    except Exception as e:
        return render_template("Admin_queue1.html", error=e)

@admin.route('/admin-details')
@login_required
def admin_details():
    try:
        see1 = session['username'].upper()
        #see1 = 'git'
        dcn, cur = get_connecttion()
        cur.execute("SELECT * FROM master_data order by Approval_paper;"),
        commentsList = cur.fetchall()
        return render_template("Admin_Order_Details.html", data=commentsList, use= see1)
    except Exception as e:
        return render_template("Admin_Order_Details.html", error=e)


@admin.route('/admin-details-INV')
@login_required
def admin_details_inv():
    try:
        see1 = session['username'].upper()
        #see1 = 'git'
        dcn, cur = get_connecttion()
        cur.execute("SELECT * FROM master_data where Approval_paper like '%-INV-%' order by Approval_paper;"),
        commentsList = cur.fetchall()
        return render_template("Admin_Order_Details_INV.html", data=commentsList, use= see1)
    except Exception as e:
        return render_template("Admin_Order_Details_INV.html", error=e)



@admin.route('/admin-details-MNT')
@login_required
def admin_details_mnt():
    try:
        see1 = session['username'].upper()
        #see1 = 'git'
        dcn, cur = get_connecttion()
        cur.execute("SELECT * FROM master_data where Approval_paper like '%-MNT-%' order by Approval_paper;"),
        commentsList = cur.fetchall()
        return render_template("Admin_Order_Details_MNT.html", data=commentsList, use= see1)
    except Exception as e:
        return render_template("Admin_Order_Details_MNT.html", error=e)


@admin.route('/admin-details-SRV')
@login_required
def admin_details_srv():
    try:
        see1 = session['username'].upper()
        #see1 = 'git'
        dcn, cur = get_connecttion()
        cur.execute("SELECT * FROM master_data where Approval_paper like '%-SRV-%' order by Approval_paper;"),
        commentsList = cur.fetchall()
        return render_template("Admin_Order_Details_SRV.html", data=commentsList, use= see1)
    except Exception as e:
        return render_template("Admin_Order_Details_SRV.html", error=e)

@admin.route('/admin-home')
@login_required
def admin_index():
    try:
        ses=session['username'].upper()
        type_dict = {}
        dcn, cur = get_connecttion()
        # data for cost
        cur.execute("select type, ROUND(SUM(geur)/100000,2),count(*) from master_data group by type;"),
        commentsList = cur.fetchall()
        for i in commentsList:
            type_dict[i[0].upper()] = i[1]
            type_dict[i[0].upper() + "Count"] = i[2]

        # data for status
        stat_dict = dict()
        cur.execute("select status, count(*) from master_data group by status;"),
        statList = cur.fetchall()
        for i in statList:
            stat_dict[i[0]] = i[1]

        stat_dict['CE'] = stat_dict[''] + stat_dict['CANCELLED']

        # data for infra category
        category_dict = {}
        cur.execute("select project_type, count(*) from master_data group by project_type;"),
        cateList = cur.fetchall()
        for i in cateList:
            category_dict[i[0]] = i[1]

        # data for Delivery LeadTime
        lead_dict = {}
        cur.execute("select count(*) from master_data where TIMESTAMPDIFF(day, gate_in , delivery_date) <=42;")
        valLead = cur.fetchall()
        for i in valLead:
            lead_dict['less6'] = i[0]

        cur.execute(
            "select count(*) from master_data where TIMESTAMPDIFF(day, gate_in , delivery_date) >=43 and TIMESTAMPDIFF(day, gate_in , delivery_date) <=56;")
        valLead = cur.fetchall()
        for i in valLead:
            lead_dict['6to8'] = i[0]

        cur.execute("select count(*) from master_data where TIMESTAMPDIFF(day, gate_in , delivery_date) >=57;")
        valLead = cur.fetchall()
        for i in valLead:
            lead_dict['greater8'] = i[0]

        return render_template("SummaryAdminHome.html", infra=type_dict, status=stat_dict, catg=category_dict, leadT=lead_dict, use=ses)
    except Exception as e:
        return render_template('error.html', error=e)
#Testing need to remove
@admin.route('/edit')
@login_required
def edit1():
    try:
        see = session['username'].upper()
        #see= 'git'
        id = request.args['id']

        dcn, cur = get_connecttion()
        cur.execute("select * from master_data where id = %s", [id])
        insertlist = cur.fetchall()
        return render_template('edit.html', datas=insertlist, use=see)
    except Exception as e:
        return render_template("Admin_Order_Details.html", error=e)

@admin.route('/admin-edit')
@login_required
def edit():
    try:
        see = session['username'].upper()
        #see= 'git'
        id = request.args['id']
        p = request.args['page']
        view = request.args['view']

        dcn, cur = get_connecttion()
        cur.execute("select a1.* from master_data as a1 join budget_label as b ON a1.approval_paper=b.approval_paper where a1.id= %s",[id])
        insertlist = cur.fetchall()
        cur.execute("select b.* from master_data as a1 join budget_label as b ON a1.approval_paper=b.approval_paper where a1.id= %s",[id])
        insertlist2 = cur.fetchall()
        return render_template('order_edit_new.html', datas=insertlist, datasb=insertlist2, use=see, pg=p , view=view)
    except Exception as e:
        return render_template("Admin_Order_Details.html", error=e)

@admin.route('/admin-fetch')
@login_required
def fetch():
    try:
        see = session['username'].upper()
        #see= 'git'

        vl = request.args['fn']
        id = request.args.get('id')

        dcn, cur = get_connecttion()
        cur.execute("select * from master_data where id = %s", [id])
        valin = cur.fetchall()
        l = valin[0][29].split('[#]')

        for i in l:
            if str(i) == str(vl):
                l.remove(i)

        filensss1 = "[#]".join(l)
        #print filensss1
        cur.execute("update master_data set Attachment = %s where id = %s", [filensss1,id])
        dcn.commit()
        print "User {} deleted the file {}".format(see,vl)
        return redirect(url_for('admin.view', id=id))


    except Exception as e:
        return render_template("Admin_Order_Details.html", error=e)


@admin.route('/admin-update', methods=['GET', 'POST'])
@login_required
def update():
    try:
        e=None
        ses = session['username'].upper()
        #ses = 'git'
        if request.method == 'POST':
            id_w = request.form['idw']
            if request.form['record'] == "":
                record = 0
            else:
                record = request.form['record']

            if request.form['desc1'] == "":
                desc1 = ''
            else:
                desc1 = request.form['desc1']
                desc1 = ' '.join(str(desc1).split())

            if request.form['typei'] == "":
                typei = ''
            else:
                typei = request.form['typei']

            if request.form['req_name'] == "":
                requester_name = ''
            else:
                requester_name = request.form['req_name']


            if request.form['Gatename'] == "":
                gatekeeper_name = ''
            else:
                gatekeeper_name = request.form['Gatename']

            if request.form['gatein'] == "":
                gate_in = None
            else:
                gate_in = request.form['gatein']

            if request.form['getout'] == "":
                gate_out = None
            else:
                gate_out = request.form['getout']

            if request.form['smu'] == "":
                smu = ''
            else:
                smu = request.form['smu']



            if request.form['rpg'] == "":
                project_type = ''
            else:
                project_type = request.form['rpg']

            if request.form['ref'] == "":
                project_ref = ''
            else:
                project_ref = request.form['ref']

            if request.form['refr'] == "":
                project_refr = ''
            else:
                project_refr = request.form['refr']

            if request.form['qty'] == "":
                qty = 0
            else:
                qty = request.form['qty']

            if request.form['inv'] == "":
                investment = 0
            else:
                investment = request.form['inv']

            if request.form['cur'] == "":
                currency = ''
            else:
                currency = request.form['cur']

            if request.form['prno'] == "":
                pr_no = ''
            else:
                pr_no = request.form['prno']

            if request.form['sappr'] == "":
                pr_in = None
            else:
                pr_in = request.form['sappr']
            if request.form['pono'] == "":
                po_no = ''
            else:
                po_no = request.form['pono']

            if request.form['sappo'] == "":
                po_in = None
            else:
                po_in = request.form['sappo']

            if request.form['del_date'] == "":
                delibery_date = None
            else:
                delibery_date = request.form['del_date']
            if request.form['cm'] == "":
                comment = ''
            else:
                comment = request.form['cm']
                comment = ' '.join(str(comment).encode('utf-8').split())

            if request.form['Geur'] == "":
                geur = 0
            else:
                geur = request.form['Geur']

            if request.form['st'] == "":
                st = ''
            else:
                st = request.form['st']

            if request.form['exdate'] == "":
                exdate = None
            else:
                exdate = request.form['exdate']

            if request.form['intdate'] == "":
                intdate = None
            else:
                intdate = request.form['intdate']

            if request.form['pwc'] == "" or request.form['pwc'] == "None":
                pwc = 0
            else:
                pwc = request.form['pwc']

            if request.form['intno'] == "":
                intno = None
            else:
                intno = request.form['intno']

            if request.form['recname'] == "":
                recname = ''
            else:
                recname = request.form['recname']
            if request.form['bjus'] == "":
                bjus = ''
            else:
                bjus = request.form['bjus']
                bjus = ' '.join(str(bjus).split())

            if request.form['cc'] == "":
                cc = 0
            else:
                cc = request.form['cc']
            if request.form['MR'] == "":
                mr = ''
            else:
                mr = request.form['MR']
            if request.form['LT'] == "":
                lt = 0
            else:
                lt = request.form['LT']

            if request.form['Oname'] == "":
                Oname = ''
            else:
                Oname = request.form['Oname']

            if request.form['Assto'] == "":
                Assto = ''
            else:
                Assto = request.form['Assto']

            if request.form['BR'] == "":
                br = ''
            else:
                br = request.form['BR']

            if request.form['VS'] == "":
                vs = ''
            else:
                vs = request.form['VS']
            if request.form['respool'] == "":
                respool = ''
            else:
                respool = request.form['respool']

            #added for additional budget
            if request.form['ext'] == "":
                ext = 0
            else:
                ext = request.form['ext']

            if request.form['mnt1'] == "":
                mnt1 = 0
            else:
                mnt1 = request.form['mnt1']

            if request.form['mnt2'] == "":
                mnt2 = 0
            else:
                mnt2 = request.form['mnt2']

            if request.form['mnt3'] == "":
                mnt3 = 0
            else:
                mnt3 = request.form['mnt3']

            if request.form['mnt4'] == "":
                mnt4 = 0
            else:
                mnt4 = request.form['mnt4']

            if request.form['mnt5'] == "":
                mnt5 = 0
            else:
                mnt5 = request.form['mnt5']

            if request.form['opex'] == "":
                opex = 0
            else:
                opex = request.form['opex']

            if request.form['mni1'] == "":
                mni1 = ''
            else:
                mni1 = request.form['mni1']

            ###
            app_id = request.form['app_id']
            title1 = request.form['title1']
            title2 = request.form['title2']
            title3 = request.form['title3']
            title4 = request.form['title4']
            title5 = request.form['title5']
            title6 = request.form['title6']
            ## Budget information
            if request.form['mnt6'] == "":
                mnt6 = 0
            else:
                mnt6 = request.form['mnt6']

            if request.form['ext2'] == "":
                ext2 = 0
            else:
                ext2 = request.form['ext2']

            if request.form['ext3'] == "":
                ext3 = 0
            else:
                ext3 = request.form['ext3']
            if request.form['ext4'] == "ext4":
                ext4 = 0
            else:
                ext4 = request.form['ext4']

            if request.form['ext5'] == "":
                ext5 = 0
            else:
                ext5 = request.form['ext5']

            if request.form['ext6'] == "":
                ext6 = 0
            else:
                ext6 = request.form['ext6']

            if request.form['inv2'] == "":
                inv2 = 0
            else:
                inv2 = request.form['inv2']

            if request.form['inv3'] == "":
                inv3 = 0
            else:
                inv3 = request.form['inv3']

            if request.form['inv4'] == "":
                inv4 = 0
            else:
                inv4 = request.form['inv4']
            if request.form['inv5'] == "":
                inv5 = 0
            else:
                inv5 = request.form['inv5']
            if request.form['inv6'] == "":
                inv6 = 0
            else:
                inv6 = request.form['inv6']

            page = request.form['page']
            view = request.form['view']

            if request.form['cco'] == "":
                cco = None
            else:
                cco = request.form['cco']

            #print page

            fileName = request.files.getlist("file[]")
            for file in fileName:
                if file.filename:
                    file.save(os.path.join(UPLOAD_FOLDER, secure_filename(file.filename)))
            filensss = "[#]".join(str(secure_filename(e.filename)).replace(" ", "_") for e in fileName)

            dcn, cur = get_connecttion()
            cur.execute("SELECT * FROM master_data where id =%s;", [id_w])
            ord = cur.fetchall()

            cur.execute("update master_data set record=%s, desc1=%s, type=%s,Requester_name=%s\
            ,Gatekeeper_name=%s ,gate_in=%s ,gate_out=%s ,smu=%s ,project_type=%s ,project_ref=%s ,QTY=%s \
            ,Investment=%s ,currency=%s ,sap_pr_no=%s ,sap_pr_in=%s ,sap_po_no=%s ,sap_po_in=%s ,status=%s ,Delivery_date=%s\
            ,comment=%s ,Geur=%s ,project_reference=%s,Expected_date=%s,Invoice_date=%s,Power_consum=%s,Reciever_name=%s,Invoice=%s,\
            cost_center=%s, MR=%s, LT=%s, Business_just=%s, order_name=%s, assigned_to=%s,BR=%s,vendor=%s,resource_pool=%s,\
            Ext=%s, mnt1=%s,mnt2=%s,mnt3=%s,mnt4=%s,mnt5=%s,opex=%s ,mnt_included=%s, cost_center_opex=%s, \
            mnt6=%s, ext2=%s, ext3=%s, ext4=%s, ext5=%s, ext6=%s, inv2=%s, inv3=%s, inv4=%s, inv5=%s, inv6=%s where id=%s",[record,desc1,typei,requester_name,gatekeeper_name,gate_in,gate_out,smu,project_type,
                        project_ref,qty,investment,currency,pr_no,pr_in,po_no,po_in,st,delibery_date,comment,
                        geur,project_refr,exdate,intdate,pwc,recname,intno,cc,mr,lt,bjus,Oname,Assto,br,vs,
                         respool,ext,mnt1,mnt2,mnt3,mnt4,mnt5,opex,mni1,cco,mnt6,ext2,ext3,ext4,ext5,ext6,inv2,inv3,inv4,inv5,inv6, id_w])
            if filensss != "":
                query = "update master_data set Attachment = concat(Attachment,'[#]" + str(filensss) + "') where id =" + id_w
                cur.execute(query)

            ##added to update budget title
            cur.execute("update budget_label set month_year1=%s,month_year2=%s,month_year3=%s,month_year4=%s,month_year5=%s,month_year6=%s where approval_paper = %s",[title1,title2,title3,title4,title5,title6,app_id])
            dcn.commit()
            try:
                if st in ('SC CREATED','PO CREATED','ORDERED','DELIVERED') and ord[0][19] != st:
                    cur.execute("SELECT * FROM master_data where id =%s;", [id_w])
                    ord1 = cur.fetchall()
                    #print "sending mail... "
                    for val in ord1:
                        global mailbodyg
                        mailbodyg = '''from: do_not_reply_OMS@amadeus.com
to: {}
cc: estrasser@amadeus.com,venkatesh.javalgeri@amadeus.com,beatrice.krueger@amadeus.com,bmaillinger@amadeus.com,Shahjahan.KABER@amadeus.com,gitrajit-singh.takhelmayum@amadeus.com,Vaibhav.SHARMA@amadeus.com,reetika.tewari@amadeus.com,kmackay@amadeus.com,daniela.lommer@amadeus.com
subject: {}: {}
Content-type: text/html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<body aria-readonly="false" style="cursor: auto;">
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tbody>
<tr>
<td align="left" bgcolor="#1886C5" style="padding-left:20px;padding-bottom:10px;padding-top:10px; color:#FFFFFF;"><img border="0" src="http://mucnwda01.os.amadeus.net:5050/static/images/favicon-amadeus.ico"  style="float: left; color:#FFFFFF"></td>
<td align="right" bgcolor="#1886C5" style="padding-right:65px;padding-bottom:10px;padding-top:10px; font-size:10px; color:#FFFFFF;"><span style="font-size:20px;">Order Management System(ICS) &nbsp;</span></td>
</tr>
<tr>
<td align="left" bgcolor="#1F5778" colspan="2" style="padding-bottom:1px;">&nbsp;</td>
</tr>
</tbody>
</table>
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tr><td>
<br><br>
<strong>Dear {},</strong>
<p>We are pleased to inform you that the following order has been <strong> {} </strong>.</p>
<br>
<a href="http://mucnwda01.os.amadeus.net:5050/track?id={}" style="border:15px solid #4D96DF;background-color:#4D96DF;color:#FFF;font-size:14px; font-family:Arial;text-decoration:none">Track Your Order</a>
<br><br>
<p><strong>Order Summary</strong></p>
<hr width="100%" align="left">

                        <div >

                            <strong>Order Number : </strong>{}<br>
                            <strong>Type of Infrastructure : </strong>{}<br>
                            <strong>Status : </strong>{} <br>
                            <strong>Division : </strong>{} <br>
                            <strong>CR/TR/WO Number : </strong><a href="http://aproach.muc.amadeus.net/NotesLink/nl?RNID={}">{}</a><br>
                            <strong>What's Required? : </strong> {} <br>
                            <strong>Business Justification : </strong>{}<br>
                            <strong>Quantity : </strong>{}<br>
                            <strong>Expected Delivery Date : </strong>{}<br>



                        </div>
<hr width="100%" align="left">

<br><br>


<strong>Kind Regards,<br />
Order Management System</strong></p>
</td></tr></table>
</body>
</html>'''.format(val[32], val[19], val[12], val[4], val[19], val[12], val[12], val[3], val[19], val[8], val[1],val[1], val[2], val[31],val[11], val[25])

                    #print mailbodyg

                    SENDMAIL = "/usr/sbin/sendmail"
                    p = os.popen("%s -t -i" % SENDMAIL, "w")
                    p.write(mailbodyg)
                    status = p.close()
                    if status:
                        print "Sendmail exit status", status
            except Exception as e:
                print e

            if view == 'view':



                return redirect(url_for('admin.view', id=id_w))
            else:
                if page == 'default':
                    return redirect(url_for('admin.admin_details'))
                elif page == 'INV':
                    return redirect(url_for('admin.admin_details_inv'))
                elif page == 'SRV':
                    return redirect(url_for('admin.admin_details_srv'))
                elif page == 'MNT':
                    return redirect(url_for('admin.admin_details_mnt'))
                elif page == 'queue':
                    return redirect(url_for('admin.admin_Q'))
    except Exception as e:
        #print e
        return render_template("Admin_Order_Details.html", error=e)

@admin.route('/admin-delete')
@login_required
def delete():
    try:
        see = session['username'].upper()
        dcn, cur = get_connecttion()

        id = request.args['id']
        page = request.args['page']
        tid = request.args['tid']

        dcn, cur = get_connecttion()
        cur.execute("update master_data set status='DELETED' where id = %s", [id])
        print "user : " + see + " deleted record id : " + id
        dcn.commit()
        #msg = tid + " deleted successfully from the system."


        if page == 'default':
            return redirect(url_for('admin.admin_details'))
        elif page == 'INV':
            return redirect(url_for('admin.admin_details_inv'))
        elif page == 'SRV':
            return redirect(url_for('admin.admin_details_srv'))
        elif page == 'MNT':
            return redirect(url_for('admin.admin_details_mnt'))
        elif page == 'queue':
            return redirect(url_for('admin.admin_Q'))
    except Exception as e:
        pass


@admin.route('/admin-view/<id>')
@login_required
def view(id):
    try:
        #see = session['username'].upper()
        see= 'Git'
        #id'] = id

        dcn, cur = get_connecttion()
        cur.execute("select a1.* from master_data as a1 join budget_label as b ON a1.approval_paper=b.approval_paper where a1.id= %s", [id])
        list1 = cur.fetchall()
        cur.execute("select b.* from master_data as a1 join budget_label as b ON a1.approval_paper=b.approval_paper where a1.id= %s", [id])
        list2 = cur.fetchall()
        return render_template('order_view.html', datas=list1, datasb=list2, use=see)
    except Exception as e:
        return render_template("Admin_Order_Details.html", error=e)


@admin.route('/manager_approved', methods=['GET', 'POST'])
def mng_pproval1():
    try:
        now = datetime.datetime.now()
        nowf = now.strftime('%Y-%m-%d')
        dcn, cur = get_connecttion()
        timenow=datetime.datetime.now().strftime('%Y%m%d%H%M%S')

        if request.method == 'POST':

            id1 = request.form['id']
            butn = request.form['buttn']
            notec = request.form['note']
            ics_app_by = request.form['ics_app_by']
            notec = ' '.join(str(notec).split())
            secret_key2 = str(timenow) + "APPSNTICS" + str(id1)
            if butn == 'ICS APPROVED':
                cur.execute("update master_data set status = %s, app_sent_check =%s, hardware=%s, final_approved_date=%s,ICS_Approved_by=%s where id = %s;", [butn,secret_key2,notec,nowf,ics_app_by, id1])
                dcn.commit()

            else:
                cur.execute("update master_data set status = %s, app_sent_check = null, hardware=%s where id = %s;",[butn, notec, id1])
                dcn.commit()
            #notification mail about the status of the approval

            cur.execute("select * from  master_data where id = %s;",[id1])
            orv= cur.fetchall()
            for v in orv:

                mailbody = '''from: do_not_reply_OMS@amadeus.com
to: estrasser@amadeus.com,venkatesh.javalgeri@amadeus.com,beatrice.krueger@amadeus.com,bmaillinger@amadeus.com,Shahjahan.KABER@amadeus.com,gitrajit-singh.takhelmayum@amadeus.com,Vaibhav.SHARMA@amadeus.com,reetika.tewari@amadeus.com,kmackay@amadeus.com,daniela.lommer@amadeus.com
subject: Order updates for {}
Content-type: text/html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">

<body aria-readonly="false" style="cursor: auto;">
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tbody>
<tr>
<td align="left" bgcolor="#1886C5" style="padding-left:20px;padding-bottom:10px;padding-top:10px; color:#FFFFFF;"><img border="0" src="http://mucnwda01.os.amadeus.net:5050/static/images/favicon-amadeus.ico"  style="float: left; color:#FFFFFF"></td>
<td align="right" bgcolor="#1886C5" style="padding-right:65px;padding-bottom:10px;padding-top:10px; font-size:10px; color:#FFFFFF;"><span style="font-size:20px;">Order Management System(ICS) &nbsp;</span></td>
</tr>
<tr>
<td align="left" bgcolor="#1F5778" colspan="2" style="padding-bottom:1px;">&nbsp;</td>
</tr>
</tbody>
</table>
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tr><td>
<br><br>
<strong>Hello Team,</strong>
<p>Order updated in the System with the Status: {} <br />
&nbsp;</p>

<p><strong>Request Summary</strong></p>
<hr width="100%" align="left">

                        <div >

                            <strong>Request Number : </strong><a href="http://mucnwda01.os.amadeus.net:5050/track?id={}">{}</a><br>
                            <strong>Type of Infrastructure : </strong>{}<br>
                            <strong>Status : </strong>{} <br>
                            <strong>Division : </strong>{} <br>
                            <strong>CR/TR/WO Number : </strong><a href="http://aproach.muc.amadeus.net/NotesLink/nl?RNID={}">{}</a><br>
                            <strong>What's Required? : </strong> {} <br>
                            <strong>Business Justification : </strong>{}<br>
                            <strong>Quantity : </strong>{}<br>
                            <strong>Expected Delivery Date : </strong>{}<br>
                            <strong>Budget Checked By : </strong>{}<br>
                            <strong>ICS Approved By : </strong>{}<br>




                        </div>
<hr width="100%" align="left">

&nbsp;

<br />
<strong>Kind Regards,<br />
Order Management System</strong></p>
</td></tr></table>
</body>
</html>'''.format(v[12],butn,v[12],v[12],v[3], v[19], v[8],v[1],v[1],v[2], v[31], v[11],v[25],v[43],v[44])
            #print mailbody
            #print "Order {} approved by {}".format(v[12],v[44])

            SENDMAIL = "/usr/sbin/sendmail"
            p = os.popen("%s -t -i" % SENDMAIL, "w")
            p.write(mailbody)
            status = p.close()
            if status:
                print "Sendmail exit status", status

                # print mailbody

            mess="Thanks for updating the status. Order Status updated to : " + butn + ". Notification sent to Respective coordinator."
            return render_template('manger_update.html', success=mess)
    except Exception as e:
        render_template('manger_update.html', error=e)




@admin.route('/manger_approval')
def mng_appr():
    try:
        id = request.args['id']
        sKey = request.args['key']
        dcn, cur = get_connecttion()
        cur.execute("select a1.* from master_data as a1 join budget_label as b ON a1.approval_paper=b.approval_paper where a1.id= %s",[id])
        mnapp1 = cur.fetchall()
        cur.execute("select b.* from master_data as a1 join budget_label as b ON a1.approval_paper=b.approval_paper where a1.id= %s",[id])
        mnapp12 = cur.fetchall()
        for va in mnapp1:
            if va[33] != None:
                if va[33] == sKey:
                    return render_template('order_approval.html', datas=mnapp1, datasb=mnapp12)
                else:
                    return render_template('manger_update.html', error="Order Already Approved!")
            else:
                return render_template('manger_update.html', error="This link is invalid. Please check with Admin")



    except Exception as e:
        return render_template('manger_update.html', error="This link is invalid. Please check with Admin")


#budget approval
@admin.route('/admin-budgetApproval', methods=['GET', 'POST'])
@login_required
def send_bgtapproval():
    global secret_key1
    try:
        see1 = session['username'].upper()
        #see = 'git'
        dcn, cur = get_connecttion()
        timenow=datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        if request.method == 'POST':
            sub = request.form['action']
            id1 = request.form['id']

            cur.execute("SELECT * FROM master_data where id =%s;", [id1])
            app_pap1 = cur.fetchall()
            for val in app_pap1:
                global mailbody
                secret_key1 = timenow + str(val[0]) + "APPSNT" + str(val[12]).replace("-", "")
                mailbody = '''from: do_not_reply_OMS@amadeus.com
to: estrasser@amadeus.com,Shahjahan.KABER@amadeus.com,gitrajit-singh.takhelmayum@amadeus.com
subject: Request for Budget Check Approval. {}
Content-type: text/html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">

<body aria-readonly="false" style="cursor: auto;">
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tbody>
<tr>
<td align="left" bgcolor="#1886C5" style="padding-left:20px;padding-bottom:10px;padding-top:10px; color:#FFFFFF;"><img border="0" src="http://mucnwda01.os.amadeus.net:5050/static/images/favicon-amadeus.ico"  style="float: left; color:#FFFFFF"></td>
<td align="right" bgcolor="#1886C5" style="padding-right:65px;padding-bottom:10px;padding-top:10px; font-size:10px; color:#FFFFFF;"><span style="font-size:20px;">Order Management System(ICS) &nbsp;</span></td>
</tr>
<tr>
<td align="left" bgcolor="#1F5778" colspan="2" style="padding-bottom:1px;">&nbsp;</td>
</tr>
</tbody>
</table>
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tr><td>
<br><br>
<strong>Hello,</strong>
<p>Please review the order and provide your approval.<br />
&nbsp;</p>

<p><strong>Order Summary</strong></p>
<hr width="100%" align="left">

                        <div >

                            <strong>Order Tracking Number : </strong><a href="http://mucnwda01.os.amadeus.net:5050/track?id={}">{}</a><br>
                            <strong>Type of Infrastructure : </strong>{}<br>
                            <strong>Status : </strong>{} <br>
                            <strong>Division : </strong>{} <br>
                            <strong>CR/TR/WO Number : </strong><a href="http://aproach.muc.amadeus.net/NotesLink/nl?RNID={}">{}</a><br>
                            <strong>What's Required? : </strong> {} <br>
                            <strong>Business Justification : </strong>{}<br>
                            <strong>Quantity : </strong>{}<br>
                            <strong>Expected Delivery Date : </strong>{}<br>



                        </div>
<hr width="100%" align="left">

&nbsp;
<p><strong><a href="http://mucnwda01.os.amadeus.net:5050/budget_approval?id={}&key={}" style="border:15px solid #4D96DF;background-color:#4D96DF;color:#FFF;font-size:14px; font-family:Arial;text-decoration:none">Approve Order</a></strong></p>


<br />
<strong>Kind Regards,<br />
Order Management System</strong></p>
</td></tr></table>
</body>
</html>

            '''.format(val[12], val[12], val[12], val[3], val[19], val[8], val[1], val[1], val[2],
                       val[31], val[11], val[25], val[0],secret_key1)
                #print mailbody

            SENDMAIL = "/usr/sbin/sendmail"
            p = os.popen("%s -t -i" % SENDMAIL, "w")
            p.write(mailbody)
            status = p.close()
            if status:
                print "Sendmail exit status", status

            #print mailbody
            cur.execute("update master_data set app_sent_check = %s, status = 'SENT BUDGET CHECK' where id = %s;", [secret_key1,id1])
            dcn.commit()
            #print "http://mucnwda01.os.amadeus.net:5050/manger_approval?id"
            #print secret_key1
            return render_template("Admin_Order_Details.html", data=app_pap1, use=see1, success="Request successfully sent for Approval")




    except Exception as e:
        return render_template("Admin_Order_Details.html", error=e)

@admin.route('/budget_approval')
def mng_appr1():
    try:
        id = request.args['id']
        sKey = request.args['key']
        dcn, cur = get_connecttion()
        cur.execute("select a1.* from master_data as a1 join budget_label as b ON a1.approval_paper=b.approval_paper where a1.id= %s",[id])
        bdtapp = cur.fetchall()
        cur.execute("select b.* from master_data as a1 join budget_label as b ON a1.approval_paper=b.approval_paper where a1.id= %s",[id])
        bdtapp2 = cur.fetchall()
        for va in bdtapp:
            if va[33] != None:
                if va[33] == sKey:
                    return render_template('order_Bgt_approval.html', datas=bdtapp, datasb=bdtapp2)
                else:
                    return render_template('manger_update.html', error="Order Action Already Taken. Hence the link Expired!")
            else:
                return render_template('manger_update.html', error="This link is invalid. Please check with Admin")



    except Exception as e:
        return render_template('manger_update.html', error="This link is invalid. Please check with Admin")


@admin.route('/budget_approved', methods=['GET', 'POST'])
def mng_bgpproval1():
    try:

        dcn, cur = get_connecttion()
        timenow=datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        now = datetime.datetime.now()
        now12 = now.strftime('%Y-%m-%d')

        if request.method == 'POST':

            id1 = request.form['id']
            to_list = request.form['ics_app']
            bgetby = request.form['bgetby']
            butn = request.form['buttn'].upper()
            #print to_list
            notec = request.form['note']
            notec = ' '.join(str(notec).split())
            #secret_key2 = str(timenow) + "APPSNTICS" + str(id1)
            if butn == 'BUDGET CHECKED':
                cur.execute("update master_data set status = %s, hardware=%s,budget_approved_date=%s, Budget_check_by=%s where id = %s;", [butn,notec,now12,bgetby, id1])
                dcn.commit()

                #code to send approval mail to Robert
                cur.execute("SELECT * FROM master_data where id =%s;", [id1])
                app_pap1 = cur.fetchall()
                for val in app_pap1:
                    global mailbody
                    secret_key1 = timenow + str(val[0]) + "APPSNT" + str(val[12]).replace("-", "")
                    mailbody = '''from: do_not_reply_OMS@amadeus.com
to: {}
subject: Request for Approval. {}
Content-type: text/html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<body aria-readonly="false" style="cursor: auto;">
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tbody>
<tr>
<td align="left" bgcolor="#1886C5" style="padding-left:20px;padding-bottom:10px;padding-top:10px; color:#FFFFFF;"><img border="0" src="http://mucnwda01.os.amadeus.net:5050/static/images/favicon-amadeus.ico"  style="float: left; color:#FFFFFF"></td>
<td align="right" bgcolor="#1886C5" style="padding-right:65px;padding-bottom:10px;padding-top:10px; font-size:10px; color:#FFFFFF;"><span style="font-size:20px;">Order Management System(ICS) &nbsp;</span></td>
</tr>
<tr>
<td align="left" bgcolor="#1F5778" colspan="2" style="padding-bottom:1px;">&nbsp;</td>
</tr>
</tbody>
</table>
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tr><td>
<br><br>
<strong>Hello,</strong>
                <p>Please review the order and provide your approval.<br />
                &nbsp;</p>

                <p><strong>Order Summary</strong></p>
                <hr width="100%" align="left">

                                        <div >

                                            <strong>Order Tracking Number : </strong><a href="http://mucnwda01.os.amadeus.net:5050/track?id={}">{}</a><br>
                                            <strong>Type of Infrastructure : </strong>{}<br>
                                            <strong>Status : </strong>{} <br>
                                            <strong>Division : </strong>{} <br>
                                            <strong>CR/TR/WO Number : </strong><a href="http://aproach.muc.amadeus.net/NotesLink/nl?RNID={}">{}</a><br>
                                            <strong>What's Required? : </strong> {} <br>
                                            <strong>Business Justification : </strong>{}<br>
                                            <strong>Quantity : </strong>{}<br>
                                            <strong>Expected Delivery Date : </strong>{}<br>



                                        </div>
                <hr width="100%" align="left">

                &nbsp;

              <p><strong><a href="http://mucnwda01.os.amadeus.net:5050/manger_approval?id={}&key={}" style="border:15px solid #4D96DF;background-color:#4D96DF;color:#FFF;font-size:14px; font-family:Arial;text-decoration:none">Approve Order</a></strong></p>


                <br />
                <strong>Kind Regards,<br />
                Order Management System</strong></p>
</td></tr></table>
</body>
</html> '''.format(to_list,val[12], val[12], val[12], val[3], val[19], val[8], val[1], val[1], val[2],
                                       val[31], val[11], val[25], val[0], secret_key1)
                    # print mailbody

                SENDMAIL = "/usr/sbin/sendmail"
                p = os.popen("%s -t -i" % SENDMAIL, "w")
                p.write(mailbody)
                status = p.close()
                if status:
                    print "Sendmail exit status", status

                #print mailbody
                print "Send mail to " + to_list + "order id :" + val[12]
                cur.execute("update master_data set app_sent_check = %s  where id = %s;", [secret_key1, id1])
                dcn.commit()
                #print "http://mucnwda01.os.amadeus.net:5050/manger_approval?id"
                #print secret_key1
                mess = "Thanks for updating the status. Order has been approved for Budget Checked and sent to Next level Approval.("+ to_list +")"
                return render_template('manger_update.html', success=mess)
            else:
                cur.execute("update master_data set status = %s, app_sent_check = null, hardware=%s where id = %s;",[butn, notec, id1])
                dcn.commit()

                mess = "Order Status updated to "+ butn +"."
                return render_template('manger_update.html', error=mess)
    except Exception as e:
        render_template('manger_update.html', error=e)





@admin.route('/admin-approval', methods=['GET', 'POST'])
@login_required
def send_approval(id):
    global secret_key1
    try:
        see1 = session['username'].upper()
        #see = 'git'
        dcn, cur = get_connecttion()
        timenow=datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        if request.method == 'POST':
            sub = request.form['action']
            id1 = request.form['id']

            cur.execute("SELECT * FROM master_data where id =%s;", [id1])
            app_pap1 = cur.fetchall()
            for val in app_pap1:
                global mailbody

                secret_key1 = timenow + str(val[0]) + "APPSNT" + str(val[12]).replace("-", "")
                mailbody = '''from: do_not_reply_OMS@amadeus.com
to: gitrajit-singh.takhelmayum@amadeus.com
subject: Request for Approval. {}
Content-type: text/html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">

<body aria-readonly="false" style="cursor: auto;">
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tbody>
<tr>
<td align="left" bgcolor="#1886C5" style="padding-left:20px;padding-bottom:10px;padding-top:10px; color:#FFFFFF;"><img border="0" src="http://mucnwda01.os.amadeus.net:5050/static/images/favicon-amadeus.ico"  style="float: left; color:#FFFFFF"></td>
<td align="right" bgcolor="#1886C5" style="padding-right:65px;padding-bottom:10px;padding-top:10px; font-size:10px; color:#FFFFFF;"><span style="font-size:20px;">Order Management System(ICS) &nbsp;</span></td>
</tr>
<tr>
<td align="left" bgcolor="#1F5778" colspan="2" style="padding-bottom:1px;">&nbsp;</td>
</tr>
</tbody>
</table>
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tr><td>
<br><br>
<strong>Hello,</strong>
<p>Please review the order and provide your approval.<br />
&nbsp;</p>

<p><strong>Order Summary</strong></p>
<hr width="100%" align="left">

                        <div >

                            <strong>Order Tracking Number : </strong><a href="http://mucnwda01.os.amadeus.net:5050/track?id={}">{}</a><br>
                            <strong>Type of Infrastructure : </strong>{}<br>
                            <strong>Status : </strong>{} <br>
                            <strong>Division : </strong>{} <br>
                            <strong>CR/TR/WO Number : </strong><a href="http://aproach.muc.amadeus.net/NotesLink/nl?RNID={}">{}</a><br>
                            <strong>What's Required? : </strong> {} <br>
                            <strong>Business Justification : </strong>{}<br>
                            <strong>Quantity : </strong>{}<br>
                            <strong>Expected Delivery Date : </strong>{}<br>



                        </div>
<hr width="100%" align="left">

&nbsp;


<p><strong><a href="http://mucnwda01.os.amadeus.net:5050/manger_approval?id={}&key={}" style="border:15px solid #4D96DF;background-color:#4D96DF;color:#FFF;font-size:14px; font-family:Arial;text-decoration:none">Approve Order</a></strong></p>


<br />
<strong>Kind Regards,<br />
Order Management System</strong></p>
</td></tr></table>
</body>
</html>

            '''.format(val[12], val[12], val[12], val[3], val[19], val[8], val[1], val[1], val[2],
                       val[31], val[11], val[25], val[0],secret_key1)
                #print mailbody

            SENDMAIL = "/usr/sbin/sendmail"
            p = os.popen("%s -t -i" % SENDMAIL, "w")
            p.write(mailbody)
            status = p.close()
            if status:
                print "Sendmail exit status", status

            #print mailbody
            cur.execute("update master_data set app_sent_check = %s where id = %s;", [secret_key1,id1])
            dcn.commit()
            #print "http://mucnwda01.os.amadeus.net:5050/manger_approval?id"
            #print secret_key1
            return render_template("Admin_Order_Details.html", data=app_pap1, use=see1, success="Request successfully sent for Approval")




    except Exception as e:
        return render_template("Admin_Order_Details.html", error=e)

@admin.route('/admin-OrderAdd')
@login_required
def add():
    ses1=session['username'].upper()
    return render_template('Add.html', use=ses1)




@admin.route('/signup/ICS2262018OMSAUTOMATIOMADMIN')
def sign_up():
    return render_template('signupMODI.html')

@admin.route('/logout')
def logout():
    session.pop('logged_in', None)
    flash("You logged out successfully!!")
    #return render_template('mainlogin.html', message=m)
    return redirect(url_for('ics.index'))
@admin.route('/forgot')
def forgot():
    return render_template('password.html')

@admin.route("/adduseraction", methods=["post"])
def add_user_action():
    # global first_name, last_name, email
    if request.form:
        user_name = request.form['usernamesignup']
        password = request.form['passwordsignup']
        email = request.form['emailsignup']
        passwd = base64.b64encode(password)
        secret_key = request.form['secret_key']
        if secret_key == 'ICS2262018OMSAUTOMATIOMADMIN':
            query = "insert into user values (0,'%s','%s','%s')"
            query = query % (user_name, passwd, email)
            try:
                dcn, cur = get_connecttion()
                cur.execute(query)
                dcn.commit()
                return render_template('Sucess.html', user=user_name )
            except Exception as e:
                e = "{} is already a user. Please use another username.".format(user_name)
                return render_template('signupMODI.html', err = e)
        else:
            return render_template('signupMODI.html', err="Secret_key is not valid. Please contact admin.")



@admin.route('/log', methods=['GET', 'POST'])
def login():
    e = None
    if request.method == 'POST':
        username_form = request.form['username']
        password_form = request.form['password']
        passwd = base64.b64encode(password_form)
        try:
            dcn, cur = get_connecttion()
            cur.execute("SELECT COUNT(1) FROM user WHERE username = %s;", [username_form]) # CHECKS IF USERNAME EXSIST
            if cur.fetchone()[0]:
                cur.execute("SELECT password FROM user WHERE username = %s;", [username_form]) # FETCH THE HASHED PASSWORD
                for row in cur.fetchall():
                    if passwd == row[0]:
                        session['logged_in'] = True

                        session['username'] = username_form

                        return redirect(url_for('admin.admin_Q'))
                    else:
                        e = "Invalid Credential"
                        return render_template('admin_login.html', error=e)
            else:
                e = "Invalid Credential"
                return render_template('admin_login.html', error=e)
        except Exception as e:

            return render_template('admin_login.html', error=e)



@admin.route('/password', methods=['GET', 'POST'])
def passwd():
    if request.method == 'POST':
        username_form  = request.form['username']
        email_form  = request.form['emailsignup']
        try:
            dcn, cur = get_connecttion()
            cur.execute("SELECT COUNT(1) FROM user WHERE username = %s;", [username_form]) # CHECKS IF USERNAME EXSIST
            if cur.fetchone()[0]:
                cur.execute("SELECT email FROM user WHERE username = %s;", [username_form]) # FETCH THE HASHED email
                for row in cur.fetchall():
                    if email_form == row[0]:
                        cur.execute("SELECT password FROM user WHERE username = %s;", [username_form])
                        for row1 in cur.fetchall():
                            pas = base64.b64decode(row1[0])
                            return render_template('password.html', user='Your Password is : '+pas)
                    else:
                        e = "Email not match. Please try again."
                        return render_template('password.html', error=e)

            else:
                e = "Invalid Credential"
                return render_template('password.html', error=e)
        except Exception as e:

            return render_template('password.html', error=e)

'''
@app.route('/signup')
def sign_up():
    return render_template('signupMODI.html')

@app.route('/dashboard')
@login_required
def dashboard():
    see = session['username']
    see1 = see.upper()
    return render_template('home_new.html', user=see1)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    flash("You logged out successfully!!")
    #return render_template('mainlogin.html', message=m)
    return redirect(url_for('index'))
@app.route('/forgot')
def forgot():
    return render_template('password.html')


'''