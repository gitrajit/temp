#-*- coding: utf-8 -*-
#__author__ =  'gitrajit-singh.takhelmayum@amadeus'
from flask import *
from MySQLdb import *
import os
import base64
from functools import wraps
import hashlib
import datetime
now = datetime.datetime.now()
now1 = now.strftime('%Y-%m-%d')
year = now.strftime('%Y')
from werkzeug.utils import secure_filename
from models import get_connecttion
ics = Blueprint('ics', __name__,template_folder='templates')
dcn, cur = get_connecttion()

#UPLOAD_FOLDER = '/home/blrauto/OMS/upload'
UPLOAD_FOLDER = './upload_file'




@ics.route('/NewRequest')
def new_request():
    try:
        return render_template('Request_form.html')
    except Exception as e:
        return redirect(url_for('ics.index'))

@ics.route('/saveNewRequest', methods=['GET', 'POST'])
def saveNewRequest():
    dcn, cur = get_connecttion()
    dict_type={'Hardware Rack': 'INV','Hardware Compute Upgrades':'INV','Hardware Compute':'INV',
               'Hardware Storage Upgrades':'INV','Hardware Storage':'INV','Hardware Network':'INV',
               'Hardware Cabling':'INV','Hardware IaaS':'INV','Software':'INV','Ext Services':'SRV',
               'CoD-Cloud Services':'SRV','Maintenance':'MNT','Maintenance Cancellation':'MNT'}
    global filen
    #import unicodedata
    try:
        if request.method == 'POST':
            if request.form['RName'] == "":
                RName = ''
            else:
                RName = unicode(request.form['RName'].encode('utf-8'), errors='ignore')


                #unicodedata.normalize('NFKD', a)
                #RName = unicode(str(request.form['RName']), errors='ignore')
                #RName = str(request.form['RName']).decode('utf-8')
                #RName = unicodedata.normalize('NFKD', RName).encode('ascii', 'ignore')

            if request.form['Divs'] == "":
                Divs = ''
            else:
                Divs = request.form['Divs']

            if request.form['RGP'] == "":
                RGP = ''
            else:
                RGP = request.form['RGP']

            if request.form['typ'] == "":
                typ = ''
            else:
                typ = request.form['typ']

            if request.form['Dloc'] == "":
                Dloc = ''
            else:
                Dloc = request.form['Dloc']

            if request.form['qnt'] == "":
                qnt = 0
            else:
                qnt = request.form['qnt']

            if request.form['pref'] == "":
                pref = ''
            else:
                pref = request.form['pref']

            if request.form['desc'] == "":
                desc = ''
            else:
                desc = str(request.form['desc'])
                desc = ' '.join(str(desc).split())

            if request.form['bjst'] == "":
                bjst = ''
            else:
                bjst = request.form['bjst']
                bjst = ' '.join(str(bjst).split())

            if request.form['Edd'] == "":
                Edd = None
            else:
                Edd = request.form['Edd']

            if request.form['pcon'] == "":
                pcon = 0
            else:
                pcon = request.form['pcon']

            if request.form['recN'] == "":
                recN = ''
            else:
                recN = request.form['recN']

            if request.form['cmt'] == "":
                cmt = ''
            else:
                cmt = request.form['cmt']
                cmt = ' '.join(str(cmt).split())

            if request.form['record'] == "":
                record = 0
            else:
                record = request.form['record']

            if request.form['Remail'] == "":
                Remail = None
            else:
                Remail = request.form['Remail']

            if request.form['cc'] == "":
                costcenter = 0
            else:
                costcenter = request.form['cc']

            if request.form['MR'] == "":
                mr = ''
            else:
                mr = request.form['MR']

            if request.form['LT'] == "":
                lt = 0
            else:
                lt = request.form['LT']

            if request.form['BR'] == "":
                br = None
            else:
                br = request.form['BR']



            fileName = request.files.getlist("file[]")
            for file in fileName:
                if file.filename:
                    file.save(os.path.join(UPLOAD_FOLDER,secure_filename(file.filename)))
            filensss = "[#]".join(str(secure_filename(e.filename)).replace(" ","_") for e in fileName)
            #print filensss
            type_name = dict_type.get(typ, 'XXX')
            #cur.execute("SELECT Approval_paper FROM master_data order by id desc limit 1;")
            cur.execute("SELECT Approval_paper FROM master_data where Approval_paper like '%-" + type_name +"-%' order by id desc limit 1;")
            app_pap = cur.fetchall()
            global k
            k=1
            for i in app_pap:
                k = int(i[0].split("-")[3]) + 1
            #type_name = dict_type.get(typ, 'XXX')
            #approval_paper = "ICS-" + type_name +"-" + str(now.year) + "-" + str('%03d' % k)
            approval_paper = "ICS-" + type_name + "-" + "2019-" + str('%03d' % k)
            lst = ['1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year', '6th Year']
            status='New'
            cur.execute("insert into master_data values(0, %s,%s,%s,%s,null,null,null,%s,%s,%s,%s,%s,0,null,null,null,null,null,%s,null,%s,null,0,%s,%s,null,%s,%s,\
            %s,null,%s,%s,null,%s,%s,%s,null,null,null,null,%s,'',null,null,%s,'',0,0,0,0,0,0,0,null,null,null,0,0,0,0,0,0,0,0,0,0,0);",
                [record,desc, typ, RName, Divs, RGP,Dloc, qnt, approval_paper,status, cmt, pref, Edd, pcon, recN, filensss, bjst,Remail,costcenter,mr,lt,br,now1])
            cur.execute("insert into budget_label values (0,%s,%s,%s,%s,%s,%s,%s)",[lst[0], lst[1], lst[2], lst[3], lst[4], lst[5], approval_paper])
            dcn.commit()



        trckr_dic = {'RFQ': 'done%todo%todo%todo%todo%todo%todo','NEW': 'done%todo%todo%todo%todo%todo%todo', 'BUSINESSCASE WIP': 'done%todo%todo%todo%todo%todo%todo',
                     'SENT BUDGET CHECK': 'done%todo%todo%todo%todo%todo%todo',
                     'ICS APPROVED': 'done%done%done%todo%todo%todo%todo',
                     'BUDGET CHECKED': 'done%done%todo%todo%todo%todo%todo',
                     'SC CREATED': 'done%done%done%done%todo%todo%todo', 'PO CREATED': 'done%done%done%done%todo%todo%todo',
                     'ORDERED': 'done%done%done%done%done%todo%todo',
                     'DELIVERED': 'done%done%done%done%done%done%todo',
                     'PARTIALLY INVOICED': 'done%done%done%done%done%done%todo',
                     'FULLY INVOICED': 'done%done%done%done%done%done%done',
                     'DELAYED': 'hold', 'ON-HOLD': 'hold', 'CANCELLED': 'hold', 'REJECT': 'hold','DELETED': 'hold',
                     'WAITING FEEDBACK': 'q'}
        cur.execute("SELECT * FROM master_data where Approval_paper =%s;", [approval_paper])
        order_track = cur.fetchall()
        trd_id = trckr_dic.get(str(order_track[0][19]).upper(), 'todo%todo%todo%todo%todo')
        for val in order_track:
            global mailbody
            mailbody = '''from: do_not_reply_OMS@amadeus.com
to: {}
cc: estrasser@amadeus.com,venkatesh.javalgeri@amadeus.com,beatrice.krueger@amadeus.com,bmaillinger@amadeus.com,Shahjahan.KABER@amadeus.com,gitrajit-singh.takhelmayum@amadeus.com,Vaibhav.SHARMA@amadeus.com,reetika.tewari@amadeus.com,kmackay@amadeus.com,daniela.lommer@amadeus.com
subject: Request Confirmation. {}
Content-type: text/html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<h1 align="">Request Confirmed!!</h1>
<br>
<body aria-readonly="false" style="cursor: auto;">
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tbody>
<tr>
<td align="left" bgcolor="#1886C5" style="padding-left:20px;padding-bottom:10px;padding-top:10px; color:#FFFFFF;"><img border="0" src="http://mucnwda01.os.amadeus.net:5050/static/images/favicon-amadeus.ico"  style="float: left; color:#FFFFFF"></td>
<td align="right" bgcolor="#1886C5" style="padding-right:65px;padding-bottom:10px;padding-top:10px; font-size:10px; color:#FFFFFF;"><span style="font-size:20px;">Order Management System(ICS) &nbsp;</span></td>
</tr>
<tr>
<td align="left" bgcolor="#1F5778" colspan="2" style="padding-bottom:1px;">&nbsp;</td>
</tr>
</tbody>
</table>
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tr><td>
<br><br>
<strong>Dear {},</strong>
<p>Request successfully placed! Please find the Request confirmation details below.</p>
<br>
<a href="http://mucnwda01.os.amadeus.net:5050/track?id={}" style="border:15px solid #4D96DF;background-color:#4D96DF;color:#FFF;font-size:14px; font-family:Arial;text-decoration:none">Track Your Order</a>
<br><br>

<p><strong>Request Summary</strong></p>
<hr width="100%" align="left">

                        <div >

                            <strong>Request Number : </strong>{}<br>
                            <strong>Type of Infrastructure : </strong>{}<br>
                            <strong>Status : </strong>{} <br>
                            <strong>Division : </strong>{} <br>
                            <strong>CR/TR/WO Number : </strong><a href="http://aproach.muc.amadeus.net/NotesLink/nl?RNID={}">{}</a><br>
                            <strong>What's Required? : </strong> {} <br>
                            <strong>Business Justification : </strong>{}<br>
                            <strong>Quantity : </strong>{}<br>
                            <strong>Expected Delivery Date : </strong>{}<br>



                        </div>
<hr width="100%" align="left">
<br>
<a href="http://mucnwda01.os.amadeus.net:5050/trackUserUpdate/{}" style="border:15px solid #4D96DF;background-color:#4D96DF;color:#FFF;font-size:14px; font-family:Arial;text-decoration:none">Add Comments</a>
<br>
&nbsp;

<p><strong>Please retain this confirmation for your records.</strong></p>

<p><strong>For more detail, please login to the&nbsp;</strong><a href="http://mucnwda01.os.amadeus.net:5050">OMS Portal</a><br />
<br />
<strong>Kind Regards,<br />
Order Management System</strong></p>
</td></tr></table>
</body>
</html>

'''.format(val[32], val[12], val[4], val[12], val[12], val[3], val[19], val[8],val[1],val[1],val[2], val[31], val[11],val[25], val[12])
        #print mailbody

        SENDMAIL = "/usr/sbin/sendmail"
        p = os.popen("%s -t -i" % SENDMAIL, "w")
        p.write(mailbody)
        status = p.close()
        if status:
            print "Sendmail exit status", status

        #print mailbody

        return render_template('order_tracking.html', track_id=trd_id, detail=order_track, success="Request Submitted scuccessfully. Your Request Reference no : {}".format(approval_paper))


    except Exception as e:

        return render_template('home.html', error=e)

def sendemail(email,id):
    try:
        pass
    except Exception as e:
        pass
@ics.route('/update/<id>')
def update(id):
    try:


        dcn, cur = get_connecttion()
        cur.execute("select * from master_data where id = %s", [id])
        list1 = cur.fetchall()
        return render_template('Request_form_update.html', datas=list1)
    except Exception as e:
        return render_template("Admin_Order_Details.html", error=e)

@ics.route('/up')
def up():
    return render_template('upload.html')

@ics.route('/uploadfile', methods=['GET', 'POST'])
def upw():

    try:
        if request.method == 'POST':
            f = request.files.getlist("file[]")
            for file in f:
                file.save(os.path.join(UPLOAD_FOLDER,secure_filename(file.filename)))
            return "success"
    except Exception as e:
        print e

        return e

@ics.route('/files/<name>')
def get_file(name):
    """Download a file."""
    try:

        return send_from_directory(UPLOAD_FOLDER, name, as_attachment=True)
    except Exception as e:
        return "Request File not found, Please check with Admin."

@ics.route('/details')
def index1():
    try:
        dcn, cur = get_connecttion()
        cur.execute("SELECT * FROM master_data order by Approval_paper;"),
        commentsList = cur.fetchall()
        return render_template("home.html", data = commentsList)
    except OperationalError as e:
        return render_template('home.html', error=e)

@ics.route('/requestForm')
def requestf():
    return render_template('/Request_form.html')

def summary():
    try:
        dcn, cur = get_connecttion()
        cur.execute("select * from master_data where id =1;")
        commentsList = cur.fetchall()
        return render_template("edit.html", data=commentsList)

    except OperationalError as e:
        return render_template('Summary.html', error=e)
@ics.route('/')
@ics.route('/home')
def index():
    try:
        type_dict1 = {}
        type_dict = {}
        dcn, cur = get_connecttion()
        # data for cost
        cur.execute("select type, IFNULL(SUM(geur)/1000000,0),count(*) from master_data where status not in ('REJECT','CANCELLED','DELETED') and type not in ('Maintenance','Ext Services') group by type;")

        commentsList = cur.fetchall()
        for i in commentsList:
            type_dict1[i[0]] = i[1]
        cur.execute("select type, IFNULL(SUM(opex)/1000000,0),count(*) from master_data where status not in ('REJECT','CANCELLED','DELETED') and type ='Maintenance';")

        commentsList1 = cur.fetchall()
        for i in commentsList1:
            type_dict1[i[0]] = i[1]
        cur.execute("select type, IFNULL(SUM(ext)/1000000,0),count(*) from master_data where status not in ('REJECT','CANCELLED','DELETED') and type ='Ext Services';")

        commentsList2 = cur.fetchall()
        for i in commentsList2:
            type_dict1[i[0]] = i[1]

        # print type_dict1
        budget_allocated = {'Hardware Cabling': 1.7, 'Hardware Network': 5.707525, 'Hardware Storage': 11.227192,
                            'Hardware Compute': 29.912550, 'Hardware IaaS': 5.895927, 'Ext Services': 6.222,
                            'CoD-Cloud Services': 11.5, 'Maintenance': 17.5, 'Software': 0}

        infra_list = ('CoD-Cloud Services', 'Ext Services', 'Hardware Cabling', 'Hardware Compute', 'Hardware IaaS',
                      'Hardware Network', 'Hardware Storage', 'Maintenance', 'Software')
        for i in infra_list:
            if i == 'Hardware Compute':
                used = float(type_dict1.get('Hardware Compute', 0)) + float(
                    type_dict1.get('Hardware Compute Upgrades', 0))
                free = float(budget_allocated[i]) - used
                type_dict[i.upper() + "used"] = '%.2f' % (used)
                type_dict[i.upper() + "Free"] = '%.2f' % (free)

            elif i == 'Hardware Storage':
                used = float(type_dict1.get('Hardware Storage', 0)) + float(
                    type_dict1.get('Hardware Storage Upgrades', 0))
                free = float(budget_allocated[i]) - used
                type_dict[i.upper() + "used"] = '%.2f' % used
                type_dict[i.upper() + "Free"] = '%.2f' % free
            elif i == 'Hardware Cabling':
                used = float(type_dict1.get('Hardware Cabling', 0)) + float(type_dict1.get('Hardware Rack', 0))
                free = float(budget_allocated[i]) - used
                type_dict[i.upper() + "used"] = '%.2f' % used
                type_dict[i.upper() + "Free"] = '%.2f' % free
            else:
                free = float(budget_allocated[i]) - float(type_dict1.get(i, 0))
                type_dict[i.upper() + "used"] = '%.2f' % float(type_dict1.get(i, 0))
                type_dict[i.upper() + "Free"] = '%.2f' % free

        # data for status
        status_dict = dict()
        dcn, cur = get_connecttion()

        cur.execute("select status, count(*) from master_data group by status;")
        order_track = cur.fetchall()
        for val in order_track:
            status_dict[val[0]] = val[1]
            # print val[0],val[1]
        # print status_dict
        status_dict['ORDERED'] = status_dict.get('ORDERED', 0)
        status_dict['OR'] = status_dict.get('RFQ', 0) + status_dict.get('BUSINESSCASE WIP', 0) + status_dict.get('New', 0)
        status_dict['OP'] = status_dict.get('SC CREATED', 0) + status_dict.get('PO CREATED', 0)
        status_dict['ICS APPROVED'] = status_dict.get('ICS APPROVED', 0)
        status_dict['BUDGET CHECKED'] = status_dict.get('BUDGET CHECKED', 0)
        status_dict['DELIVERED'] = status_dict.get('DELIVERED', 0) + status_dict.get('PARTIALLY INVOICED', 0) + status_dict.get('FULLY INVOICED', 0)
        status_dict['SENT BUDGET CHECK'] = status_dict.get('SENT BUDGET CHECK', 0)

        # data for infra category
        category_dict={}
        cur.execute("select project_type, count(*) from master_data group by project_type;"),
        cateList = cur.fetchall()
        for i in cateList:
            category_dict[i[0]] = i[1]
        category_dict['RUN'] = category_dict.get('RUN', 0)
        category_dict['GROW'] = category_dict.get('GROW', 0)
        category_dict['PROJECT'] = category_dict.get('PROJECT', 0)

        #data for Delivery LeadTime
        lead_dict={}
        cur.execute("select count(*) from master_data where TIMESTAMPDIFF(day, gate_in , delivery_date) <=42;")
        valLead= cur.fetchall()
        for i in valLead:
            lead_dict['less6'] = i[0]

        cur.execute("select count(*) from master_data where TIMESTAMPDIFF(day, gate_in , delivery_date) >=43 and TIMESTAMPDIFF(day, gate_in , delivery_date) <=56;")
        valLead = cur.fetchall()
        for i in valLead:
            lead_dict['6to8'] = i[0]

        cur.execute("select count(*) from master_data where TIMESTAMPDIFF(day, gate_in , delivery_date) >=57;")
        valLead = cur.fetchall()
        for i in valLead:
            lead_dict['greater8'] = i[0]


        return render_template("Summaryhome_check.html", y=year,infra=type_dict, status=status_dict, catg=category_dict, leadT=lead_dict)
    except Exception as e:
        return render_template('error.html', error=e)


@ics.route('/viewDetails')
def view():
    try:
        first = request.args['types']
        second= request.args['type']

        dcn, cur = get_connecttion()
        if second == 'OR':
            sql = "select * from master_data where status in ('RFQ','BUSINESSCASE WIP','New');"
            cur.execute(sql)
            comments = cur.fetchall()
        elif second == 'OP':
            sql = "select * from master_data where status in ('SC CREATED','PO CREATED');"
            cur.execute(sql)
            comments = cur.fetchall()
        elif second == 'DELIVERED':
            sql = "select * from master_data where status in ('DELIVERED','PARTIALLY INVOICED','FULLY INVOICED');"
            cur.execute(sql)
            comments = cur.fetchall()
        else:
            sql = "select * from master_data where {} = '{}'".format(first, second)
            cur.execute(sql)
            comments = cur.fetchall()

        return render_template("home.html", data=comments)

    except Exception as e:
        return render_template('home.html', error=e)

@ics.route('/track')
def track():
    try:
        id = request.args['id']
        dcn, cur = get_connecttion()
        trckr_dic = {'RFQ': 'done%todo%todo%todo%todo%todo%todo','NEW': 'done%todo%todo%todo%todo%todo%todo', 'BUSINESSCASE WIP': 'done%todo%todo%todo%todo%todo%todo',
                     'SENT BUDGET CHECK': 'done%todo%todo%todo%todo%todo%todo',
                     'ICS APPROVED': 'done%done%done%todo%todo%todo%todo',
                     'BUDGET CHECKED': 'done%done%todo%todo%todo%todo%todo',
                     'SC CREATED': 'done%done%done%done%todo%todo%todo', 'PO CREATED': 'done%done%done%done%todo%todo%todo',
                     'ORDERED': 'done%done%done%done%done%todo%todo',
                     'DELIVERED': 'done%done%done%done%done%done%todo',
                     'PARTIALLY INVOICED': 'done%done%done%done%done%done%todo',
                     'FULLY INVOICED': 'done%done%done%done%done%done%done',
                     'DELAYED': 'hold', 'ON-HOLD': 'hold', 'CANCELLED': 'hold', 'REJECT': 'hold','DELETED': 'hold',
                     'WAITING FEEDBACK': 'q'}
        cur.execute("select * from master_data where Approval_paper = %s",[id])
        order_track = cur.fetchall()
        trd_id = trckr_dic.get(str(order_track[0][19]).upper(), 'todo%todo%todo%todo%todo%todo')
        return render_template('order_tracking.html', track_id=trd_id, detail=order_track)
    except Exception as e:
        return render_template('order_tracking.html', error=e)

@ics.route('/trackUserUpdate/<id>')
def trackU(id):
    try:
        dcn, cur = get_connecttion()
        trckr_dic = {'RFQ': 'done%todo%todo%todo%todo%todo%todo','NEW': 'done%todo%todo%todo%todo%todo%todo', 'BUSINESSCASE WIP': 'done%todo%todo%todo%todo%todo%todo',
                     'SENT BUDGET CHECK': 'done%todo%todo%todo%todo%todo%todo',
                     'ICS APPROVED': 'done%done%done%todo%todo%todo%todo',
                     'BUDGET CHECKED': 'done%done%todo%todo%todo%todo%todo',
                     'SC CREATED': 'done%done%done%done%todo%todo%todo', 'PO CREATED': 'done%done%done%done%todo%todo%todo',
                     'ORDERED': 'done%done%done%done%done%todo%todo',
                     'DELIVERED': 'done%done%done%done%done%done%todo',
                     'PARTIALLY INVOICED': 'done%done%done%done%done%done%todo',
                     'FULLY INVOICED': 'done%done%done%done%done%done%done',
                     'DELAYED': 'hold', 'ON-HOLD': 'hold', 'CANCELLED': 'hold', 'REJECT': 'hold','DELETED': 'hold',
                     'WAITING FEEDBACK': 'q'}
        cur.execute("select * from master_data where Approval_paper = %s",[id])
        order_track = cur.fetchall()
        trd_id = trckr_dic.get(str(order_track[0][19]).upper(), 'todo%todo%todo%todo%todo%todo')
        return render_template('order_tracking_userupdate.html', track_id=trd_id, detail=order_track)
    except Exception as e:
        return render_template('order_tracking.html', error=e)


@ics.route('/sveUserComment', methods = ['GET', 'POST'])
def userCommentSave():
    try:
        dcn, cur = get_connecttion()
        id_w = request.form['id']
        trackerid = request.form['trackerid']
        if request.method == 'POST':

            if request.form['ucmtn'] == "":
                ucmtn = ''
            else:
                stringu = "Dated : {} : {}".format(now1,request.form['ucmtn'])
                #query = "update master_data set user_comment = concat(user_comment,{}) where Approval_paper = {};".format(str(stringu), id_w)

                query = "update master_data set user_comment = IFNULL(concat(user_comment,'\n','" + str(stringu) + "'),'" + str(stringu) + "') where id =" + id_w

                cur.execute(query)
                dcn.commit()
                cur.execute("select * from master_data where id =%s",[id_w])
                or_val = cur.fetchall()
                for val in or_val:
                    mailbody = '''from: do_not_reply_OMS@amadeus.com
to: estrasser@amadeus.com,venkatesh.javalgeri@amadeus.com,beatrice.krueger@amadeus.com,bmaillinger@amadeus.com,Shahjahan.KABER@amadeus.com,gitrajit-singh.takhelmayum@amadeus.com,Vaibhav.SHARMA@amadeus.com,reetika.tewari@amadeus.com,kmackay@amadeus.com,daniela.lommer@amadeus.com
cc: {}
subject: User Comments for tracker_id: {}
Content-type: text/html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<body aria-readonly="false" style="cursor: auto;">
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tbody>
<tr>
<td align="left" bgcolor="#1886C5" style="padding-left:20px;padding-bottom:10px;padding-top:10px; color:#FFFFFF;"><img border="0" src="http://mucnwda01.os.amadeus.net:5050/static/images/favicon-amadeus.ico"  style="float: left; color:#FFFFFF"></td>
<td align="right" bgcolor="#1886C5" style="padding-right:65px;padding-bottom:10px;padding-top:10px; font-size:10px; color:#FFFFFF;"><span style="font-size:20px;">Order Management System(ICS) &nbsp;</span></td>
</tr>
<tr>
<td align="left" bgcolor="#1F5778" colspan="2" style="padding-bottom:1px;">&nbsp;</td>
</tr>
</tbody>
</table>
<table border="0" cellpadding="5" cellspacing="0" style="margin: auto;" width="600">
<tr><td>
<br>
<strong>Hi All,</strong>
<br>
<p>Requester have updated the below comments.</p>
<br>
<fieldset>
	<legend>
Message:
	</legend>
{}
</fieldset>
<br><br><br>
<a href="http://mucnwda01.os.amadeus.net:5050/track?id={}" style="border:15px solid #4D96DF;background-color:#4D96DF;color:#FFF;font-size:14px; font-family:Arial;text-decoration:none">Track Your Order</a>
<br><br>

<p><strong>Request Summary</strong></p>
<hr width="100%" align="left">

                        <div >

                            <strong>Request Number : </strong>{}<br>
                            <strong>Type of Infrastructure : </strong>{}<br>
                            <strong>Status : </strong>{} <br>
                            <strong>Division : </strong>{} <br>
                            <strong>CR/TR/WO Number : </strong><a href="http://aproach.muc.amadeus.net/NotesLink/nl?RNID={}">{}</a><br>
                            <strong>What's Required? : </strong> {} <br>
                            <strong>Business Justification : </strong>{}<br>
                            <strong>Quantity : </strong>{}<br>
                            <strong>Expected Delivery Date : </strong>{}<br>



                        </div>
<hr width="100%" align="left">

&nbsp;

<p><strong>For more detail, please login to the&nbsp;</strong><a href="http://mucnwda01.os.amadeus.net:5050">OMS Portal</a><br />
<br />
<strong>Kind Regards,<br />
Order Management System</strong></p>
</td></tr></table>
</body>
</html>

'''.format(val[32], val[12], val[55].replace('\n', '<br>'), val[12], val[12], val[3], val[19], val[8], val[1], val[1], val[2], val[31], val[11], val[25])
                #print mailbody

                SENDMAIL = "/usr/sbin/sendmail"
                p = os.popen("%s -t -i" % SENDMAIL, "w")
                p.write(mailbody)
                status = p.close()
                if status:
                    print "Sendmail exit status", status


        return redirect(url_for('ics.trackU', id=trackerid))

    except Exception as e:
        print e


@ics.route('/viewdetails')
def views():
    try:
        first = request.args['type']
        dcn, cur = get_connecttion()

        if first == 'lessThan6':
            cur.execute("select * from master_data where TIMESTAMPDIFF(day, gate_in , delivery_date) <=42;")


        elif first == 'between6to8':

            cur.execute("select * from master_data where TIMESTAMPDIFF(day, gate_in , delivery_date) >=43 and TIMESTAMPDIFF(day, gate_in , delivery_date) <=56 ;")

        else:
            cur.execute("select * from master_data where TIMESTAMPDIFF(day, gate_in , delivery_date) >=57;")

        valLead = cur.fetchall()
        return render_template("home.html", data=valLead)
    except Exception as e:
        return render_template('home.html', error=e)

@ics.route("/test")
def test():
    try:

        return render_template("test.html")

    except OperationalError as e:
        return render_template('Summary.html', error=e)

@ics.route("/test1")
def test1():
    try:

        return 'directConnectGatewayState{job="directConnectGateways",connection_id="AwsMcpTransitProdEUDX",} 1'

    except OperationalError as e:
        return render_template('Summary.html', error=e)






