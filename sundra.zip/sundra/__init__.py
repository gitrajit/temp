# -*- coding: utf-8 -*-
#__author__ =  'gitrajit-singh.takhelmayum@amadeus'
from __future__ import unicode_literals
import base64
from flask import *
import os
from datetime import datetime
from functools import wraps

import MySQLdb
#from flask_sslify import SSLify
from models import get_connecttion

from views.home import *
from views.admin import *
import logging
logging.basicConfig(level=logging.INFO)

app = Flask(__name__)
app.register_blueprint(ics)
app.register_blueprint(admin)


app.secret_key = os.urandom(24)


if __name__ == '__main__':
    #app.run(host='aptapttm001',port=5050, debug=False, threaded=True)
    #app.run(host='172.22.245.66',port=9256, debug=True)
    app.run(host='localhost', port=5050,threaded=True,debug=False)